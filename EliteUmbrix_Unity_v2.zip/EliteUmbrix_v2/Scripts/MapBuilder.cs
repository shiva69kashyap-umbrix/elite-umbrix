using System.Collections.Generic;
using UnityEngine;
using Unity.AI.Navigation;

public class MapInfo { public List<Vector3> roomCenters = new List<Vector3>(); }

// Generates a big random maze of rooms with doors and crates, then bakes the NavMesh for the guards.
public static class MapBuilder
{
    public const float Cell = 14f;
    static readonly Color WallCol = new Color(.24f, .27f, .35f);

    public static MapInfo Build(Transform root, int cols, int rows, int seed)
    {
        var rng = new System.Random(seed); var info = new MapInfo();
        float W = cols * Cell, H = rows * Cell;
        var floor = Prim.Cube(root, new Vector3(W / 2, -.05f, H / 2), new Vector3(W, .1f, H), new Color(.09f, .1f, .14f), "Floor", true);

        var east = new bool[cols, rows]; var north = new bool[cols, rows]; var seen = new bool[cols, rows];
        var st = new Stack<Vector2Int>(); st.Push(Vector2Int.zero); seen[0, 0] = true;
        var dirs = new[] { Vector2Int.right, Vector2Int.left, Vector2Int.up, Vector2Int.down };
        while (st.Count > 0)
        {
            var c = st.Peek(); var opts = new List<Vector2Int>();
            foreach (var d in dirs) { var n = c + d; if (n.x >= 0 && n.y >= 0 && n.x < cols && n.y < rows && !seen[n.x, n.y]) opts.Add(n); }
            if (opts.Count == 0) { st.Pop(); continue; }
            var nx = opts[rng.Next(opts.Count)];
            if (nx.x > c.x) east[c.x, c.y] = true; else if (nx.x < c.x) east[nx.x, nx.y] = true;
            else if (nx.y > c.y) north[c.x, c.y] = true; else north[nx.x, nx.y] = true;
            seen[nx.x, nx.y] = true; st.Push(nx);
        }
        for (int i = 0; i < cols * rows / 2; i++) { east[rng.Next(Mathf.Max(1, cols - 1)), rng.Next(rows)] = true; north[rng.Next(cols), rng.Next(Mathf.Max(1, rows - 1))] = true; }

        for (int y = 0; y < rows; y++) { Line(root, 0, y * Cell, (y + 1) * Cell, true, false); Line(root, W, y * Cell, (y + 1) * Cell, true, false); }
        for (int x = 0; x < cols; x++) { Line(root, 0, x * Cell, (x + 1) * Cell, false, false); Line(root, H, x * Cell, (x + 1) * Cell, false, false); }
        for (int x = 0; x < cols - 1; x++) for (int y = 0; y < rows; y++) Line(root, (x + 1) * Cell, y * Cell, (y + 1) * Cell, true, east[x, y]);
        for (int x = 0; x < cols; x++) for (int y = 0; y < rows - 1; y++) Line(root, (y + 1) * Cell, x * Cell, (x + 1) * Cell, false, north[x, y]);

        for (int y = 0; y < rows; y++) for (int x = 0; x < cols; x++)
        {
            var ctr = new Vector3((x + .5f) * Cell, 0, (y + .5f) * Cell); info.roomCenters.Add(ctr);
            if (x == 0 && y == 0) continue;
            int crates = rng.Next(3);
            for (int k = 0; k < crates; k++)
            {
                float ox = (rng.Next(2) * 2 - 1) * (2.5f + (float)rng.NextDouble() * 2.5f), oz = (rng.Next(2) * 2 - 1) * (2.5f + (float)rng.NextDouble() * 2.5f);
                Prim.Cube(root, ctr + new Vector3(ox, .8f, oz), new Vector3(1.6f, 1.6f, 1.6f), new Color(.42f, .3f, .18f), "Crate", true);
            }
        }
        floor.AddComponent<NavMeshSurface>().BuildNavMesh();
        return info;
    }

    // A wall along one grid line; if 'door' is true a 4-unit gap is left in the middle.
    static void Line(Transform r, float fixedC, float a, float b, bool alongZ, bool door)
    {
        if (!door) { Seg(r, fixedC, a, b, alongZ); return; }
        float mid = (a + b) / 2; Seg(r, fixedC, a, mid - 2, alongZ); Seg(r, fixedC, mid + 2, b, alongZ);
    }
    static void Seg(Transform r, float fixedC, float a, float b, bool alongZ)
    {
        float len = b - a, c = (a + b) / 2;
        var pos = alongZ ? new Vector3(fixedC, 1.5f, c) : new Vector3(c, 1.5f, fixedC);
        var sc = alongZ ? new Vector3(.6f, 3f, len) : new Vector3(len, 3f, .6f);
        Prim.Cube(r, pos, sc, WallCol, "Wall", true);
    }
}
