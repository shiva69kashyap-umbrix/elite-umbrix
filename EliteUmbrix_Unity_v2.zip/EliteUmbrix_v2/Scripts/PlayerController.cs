using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public int hp = 3; public bool dead; public System.Action OnDeath;
    TouchJoystick joy; Weapon gun; CharacterController cc; Transform muzzle, model; float cd;

    public void Init(Weapon w, TouchJoystick j)
    {
        joy = j; gun = w;
        cc = gameObject.AddComponent<CharacterController>(); cc.height = 1.8f; cc.radius = .4f; cc.center = new Vector3(0, .9f, 0);
        Transform mount; model = Prim.Person(transform, new Color(.12f, .62f, .52f), new Color(.05f, .36f, .31f), new Color(.88f, .67f, .54f), out mount);
        muzzle = Weapons.Build(w, mount).Find("Muzzle");
        gameObject.AddComponent<Walker>();
    }

    void Update()
    {
        if (dead) return;
        Vector3 mv = new Vector3(joy.Value.x, 0, joy.Value.y); if (mv.sqrMagnitude > 1) mv.Normalize();
        cc.Move((mv * 5.2f + Vector3.down * 2f) * Time.deltaTime);

        Guard tg = null; float bd = gun.range; Vector3 a = transform.position + Vector3.up * 1.2f;
        foreach (var g in Guard.All)
        {
            if (g.hp <= 0) continue;
            Vector3 b = g.transform.position + Vector3.up * 1.2f; float d = Vector3.Distance(a, b);
            RaycastHit h;
            if (d < bd && Physics.Raycast(a, (b - a).normalized, out h, d + .5f, ~0, QueryTriggerInteraction.Ignore) && h.collider.GetComponentInParent<Guard>() == g) { bd = d; tg = g; }
        }
        cd -= Time.deltaTime;
        if (tg != null)
        {
            Vector3 f = tg.transform.position - transform.position; f.y = 0;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(f), Time.deltaTime * 14f);
            if (cd <= 0)   // AUTO FIRE
            {
                for (int k = 0; k < gun.pellets; k++)
                {
                    Vector3 from = muzzle.position, dir = (tg.transform.position + Vector3.up * 1.2f - from).normalized;
                    dir = Quaternion.Euler(0, Random.Range(-gun.spread, gun.spread), 0) * dir;
                    Bullet.Spawn(from, dir, gun.speed, gun.damage, gun.range, true, gun.pierce, gun.color);
                }
                cd = gun.rate;
            }
        }
        else if (mv.sqrMagnitude > .01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(mv), Time.deltaTime * 10f);
    }

    public void Hurt()
    {
        if (dead) return; hp--;
        if (hp <= 0) { dead = true; model.localRotation = Quaternion.Euler(-90, 0, 0); if (OnDeath != null) OnDeath(); }
    }
}
