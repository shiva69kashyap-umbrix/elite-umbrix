using UnityEngine;

// Builds simple 3D shapes and "person" models from primitives (no art assets needed).
public static class Prim
{
    static Shader sh;
    public static Material Mat(Color c)
    {
        if (sh == null) sh = Shader.Find("Standard");
        if (sh == null) sh = Shader.Find("Universal Render Pipeline/Lit");
        var m = new Material(sh); m.color = c; return m;
    }
    public static GameObject Make(PrimitiveType t, Transform p, Vector3 pos, Vector3 scale, Color c, string name, bool collider)
    {
        var g = GameObject.CreatePrimitive(t); g.name = name;
        g.transform.SetParent(p, false); g.transform.localPosition = pos; g.transform.localScale = scale;
        g.GetComponent<Renderer>().material = Mat(c);
        if (!collider) Object.Destroy(g.GetComponent<Collider>());
        return g;
    }
    public static GameObject Cube(Transform p, Vector3 pos, Vector3 scale, Color c, string name = "Part", bool collider = false)
    { return Make(PrimitiveType.Cube, p, pos, scale, c, name, collider); }
    public static GameObject Sphere(Transform p, Vector3 pos, Vector3 scale, Color c, string name = "Part")
    { return Make(PrimitiveType.Sphere, p, pos, scale, c, name, false); }

    // Person with head, helmet, vest, arms and two legs. 'mount' is where the gun is attached.
    public static Transform Person(Transform parent, Color shirt, Color vest, Color skin, out Transform mount)
    {
        var m = new GameObject("Model").transform; m.SetParent(parent, false);
        foreach (int s in new[] { -1, 1 })
        {
            var leg = new GameObject(s < 0 ? "LegL" : "LegR").transform; leg.SetParent(m, false);
            leg.localPosition = new Vector3(.17f * s, .8f, 0);
            Cube(leg, new Vector3(0, -.4f, 0), new Vector3(.3f, .8f, .32f), new Color(.12f, .13f, .16f));
        }
        Cube(m, new Vector3(0, 1.15f, 0), new Vector3(.7f, .7f, .4f), shirt, "Torso");
        Cube(m, new Vector3(0, 1.2f, 0), new Vector3(.76f, .5f, .46f), vest, "Vest");
        Sphere(m, new Vector3(0, 1.7f, 0), Vector3.one * .6f, skin, "Head");
        Sphere(m, new Vector3(0, 1.84f, 0), new Vector3(.68f, .4f, .68f), vest, "Helmet");
        Cube(m, new Vector3(-.42f, 1.2f, .25f), new Vector3(.18f, .18f, .6f), skin, "ArmL");
        Cube(m, new Vector3(.42f, 1.2f, .25f), new Vector3(.18f, .18f, .6f), skin, "ArmR");
        mount = new GameObject("GunMount").transform; mount.SetParent(m, false);
        mount.localPosition = new Vector3(0, 1.1f, .35f);
        return m;
    }
}

// Swings the legs while the character moves.
public class Walker : MonoBehaviour
{
    Transform l, r; Vector3 last; float ph;
    void Start() { l = Find("LegL"); r = Find("LegR"); last = transform.position; }
    Transform Find(string n) { foreach (var c in GetComponentsInChildren<Transform>()) if (c.name == n) return c; return null; }
    void Update()
    {
        float sp = (transform.position - last).magnitude / Mathf.Max(Time.deltaTime, .0001f); last = transform.position;
        float a = Mathf.Clamp01(sp / 3f); ph += Time.deltaTime * sp * 2.2f;
        if (l) l.localRotation = Quaternion.Euler(Mathf.Sin(ph) * 40f * a, 0, 0);
        if (r) r.localRotation = Quaternion.Euler(-Mathf.Sin(ph) * 40f * a, 0, 0);
    }
}
