using System.Collections.Generic;

// Languages: 0 = Hindi, 1 = English, 2 = Punjabi
public static class Loc
{
    public static int Lang = 1;
    static readonly Dictionary<string, string[]> T = new Dictionary<string, string[]>
    {
        {"lvl",    new[]{"लेवल","Level","ਲੈਵਲ"}},
        {"coins",  new[]{"सिक्के","Coins","ਸਿੱਕੇ"}},
        {"guards", new[]{"गार्ड","Guards","ਗਾਰਡ"}},
        {"dead",   new[]{"तुम मारे गए","You died","ਤੂੰ ਮਾਰਿਆ ਗਿਆ"}},
        {"deadS",  new[]{"लेवल {n} दोबारा खेलो","Retry level {n}","ਲੈਵਲ {n} ਦੁਬਾਰਾ ਖੇਡੋ"}},
        {"again",  new[]{"दोबारा खेलो","Try again","ਦੁਬਾਰਾ ਖੇਡੋ"}},
        {"win",    new[]{"लेवल पार!","Level cleared!","ਲੈਵਲ ਪਾਰ!"}},
        {"winS",   new[]{"अगला लेवल {n}","Next level {n}","ਅਗਲਾ ਲੈਵਲ {n}"}},
        {"next",   new[]{"अगला लेवल","Next level","ਅਗਲਾ ਲੈਵਲ"}},
        {"startS", new[]{"पहले अपनी गन चुनो","Choose your gun first","ਪਹਿਲਾਂ ਆਪਣੀ ਬੰਦੂਕ ਚੁਣੋ"}},
        {"play",   new[]{"खेल शुरू करो","Start game","ਖੇਡ ਸ਼ੁਰੂ ਕਰੋ"}},
        {"pick",   new[]{"चुनो","Select","ਚੁਣੋ"}},
        {"picked", new[]{"चुनी हुई","Equipped","ਚੁਣੀ ਹੋਈ"}},
        {"buy",    new[]{"खरीदो","Buy","ਖਰੀਦੋ"}},
        {"quit",   new[]{"बाहर निकलो","Quit","ਬਾਹਰ ਨਿਕਲੋ"}},
        {"tip",    new[]{"टिप: गार्ड्स को मारकर सिक्के कमाओ और नई गन अनलॉक करो","Tip: Kill guards to earn coins and unlock new guns","ਟਿੱਪ: ਗਾਰਡਾਂ ਨੂੰ ਮਾਰ ਕੇ ਸਿੱਕੇ ਕਮਾਓ ਅਤੇ ਨਵੀਆਂ ਬੰਦੂਕਾਂ ਖੋਲ੍ਹੋ"}},
    };
    public static string Get(string k) { return T[k][Lang]; }
}
