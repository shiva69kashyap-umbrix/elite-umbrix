using UnityEngine;

// Floating joystick: touch anywhere and drag. Also works with WASD / arrow keys and the mouse in the Editor.
public class TouchJoystick : MonoBehaviour
{
    public Vector2 Value; public bool Enabled; bool active; int fid = -1; Vector2 origin, cur;
    float R { get { return Screen.height * .07f; } }

    void Update()
    {
        Value = Vector2.zero;
        if (!Enabled) { active = false; fid = -1; return; }
        if (Input.touchCount > 0)
        {
            foreach (var t in Input.touches)
            {
                if (!active && t.phase == TouchPhase.Began) { active = true; fid = t.fingerId; origin = t.position; cur = origin; }
                else if (active && t.fingerId == fid) { cur = t.position; if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) { active = false; fid = -1; } }
            }
        }
        else if (fid != -1) { active = false; fid = -1; }
        else
        {
            if (Input.GetMouseButtonDown(0)) { active = true; origin = Input.mousePosition; }
            if (active) { cur = Input.mousePosition; if (Input.GetMouseButtonUp(0)) active = false; }
        }
        if (active) Value = Vector2.ClampMagnitude((cur - origin) / R, 1f);
        Value = Vector2.ClampMagnitude(Value + new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")), 1f);
    }

    public void Draw(Texture2D ring, Texture2D dot)
    {
        if (!active) return;
        Vector2 o = new Vector2(origin.x, Screen.height - origin.y), k = o + Vector2.ClampMagnitude(new Vector2(cur.x - origin.x, -(cur.y - origin.y)), R);
        GUI.DrawTexture(new Rect(o.x - R, o.y - R, 2 * R, 2 * R), ring);
        GUI.DrawTexture(new Rect(k.x - R * .35f, k.y - R * .35f, R * .7f, R * .7f), dot);
    }
}
