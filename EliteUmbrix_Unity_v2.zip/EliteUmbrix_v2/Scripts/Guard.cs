using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

// Guards patrol the whole map using the NavMesh (so they never get stuck on walls).
public class Guard : MonoBehaviour
{
    public static List<Guard> All = new List<Guard>();
    public int hp = 100; public bool alert; public System.Action<Guard> OnDie;
    PlayerController pc; Transform player, model; NavMeshAgent ag; Light cone; List<Vector3> rooms; float shootCd = 1f, waitT;

    void OnEnable() { All.Add(this); }
    void OnDisable() { All.Remove(this); }

    public void Init(PlayerController p, List<Vector3> r)
    {
        pc = p; player = p.transform; rooms = r;
        Transform mount; model = Prim.Person(transform, new Color(.48f, .14f, .15f), new Color(.17f, .19f, .22f), new Color(.85f, .64f, .52f), out mount);
        Weapons.Build(Weapons.All[0], mount); gameObject.AddComponent<Walker>();
        var col = gameObject.AddComponent<CapsuleCollider>(); col.height = 1.8f; col.radius = .4f; col.center = new Vector3(0, .9f, 0);
        ag = gameObject.AddComponent<NavMeshAgent>(); ag.speed = 2.2f; ag.angularSpeed = 420; ag.acceleration = 16; ag.radius = .4f; ag.height = 1.8f; ag.stoppingDistance = .2f;
        cone = new GameObject("VisionCone").AddComponent<Light>(); cone.transform.SetParent(transform, false); cone.transform.localPosition = new Vector3(0, 1.6f, .3f);
        cone.type = LightType.Spot; cone.spotAngle = 64; cone.range = 12; cone.intensity = 5; cone.color = new Color(1f, .85f, .4f);
    }

    void Update()
    {
        if (hp <= 0 || pc == null || pc.dead) { if (ag != null && ag.enabled && ag.isOnNavMesh) ag.isStopped = true; return; }
        Vector3 eye = transform.position + Vector3.up * 1.5f, tp = player.position + Vector3.up * 1.2f, to = tp - eye; float d = to.magnitude;
        bool see = false;
        if (d < (alert ? 16f : 12f) && Vector3.Angle(transform.forward, new Vector3(to.x, 0, to.z)) < (alert ? 180f : 32f))
        {
            RaycastHit h; see = !Physics.Raycast(eye, to.normalized, out h, d, ~0, QueryTriggerInteraction.Ignore) || h.transform.IsChildOf(player);
        }
        if (see && !alert) Alert();

        if (alert)
        {
            if (see && d < 8f)
            {
                ag.isStopped = true; Vector3 f = player.position - transform.position; f.y = 0;
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(f), Time.deltaTime * 8f);
                shootCd -= Time.deltaTime;
                if (shootCd <= 0)
                {
                    Vector3 from = transform.position + Vector3.up * 1.1f + transform.forward * .9f;
                    Bullet.Spawn(from, (tp - from).normalized, 22f, 1, 20f, false, false, new Color(1f, .45f, .45f)); shootCd = 1f;
                }
            }
            else { ag.isStopped = false; ag.SetDestination(player.position); }
        }
        else if (!ag.pathPending && ag.remainingDistance < .6f)
        {
            waitT -= Time.deltaTime;
            if (waitT <= 0)
            {
                Vector3 c = rooms[Random.Range(0, rooms.Count)] + new Vector3(Random.Range(-4f, 4f), 0, Random.Range(-4f, 4f)); NavMeshHit nh;
                if (NavMesh.SamplePosition(c, out nh, 4f, NavMesh.AllAreas)) ag.SetDestination(nh.position);
                waitT = Random.Range(.3f, 1.5f);
            }
        }
    }

    void Alert()
    {
        alert = true; ag.speed = 4f; cone.color = new Color(1f, .3f, .3f);
        foreach (var g in All) if (g != null && g.hp > 0 && !g.alert && Vector3.Distance(g.transform.position, transform.position) < 10f) g.Alert();
    }

    public void TakeDamage(int dmg)
    {
        if (hp <= 0) return; hp -= dmg; if (!alert) Alert();
        if (hp <= 0)
        {
            ag.enabled = false; cone.enabled = false; GetComponent<CapsuleCollider>().enabled = false;
            if (OnDie != null) OnDie(this); StartCoroutine(Fall());
        }
    }
    IEnumerator Fall()
    {
        float t = 0; while (t < .4f) { t += Time.deltaTime; model.localRotation = Quaternion.Euler(-90 * Mathf.Clamp01(t / .4f), 0, 0); yield return null; }
        Destroy(gameObject, 2f);
    }
}
