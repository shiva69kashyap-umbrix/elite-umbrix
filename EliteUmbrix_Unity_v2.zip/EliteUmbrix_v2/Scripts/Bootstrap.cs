using System.Collections;
using UnityEngine;
using UnityEngine.AI;

// Attach this ONE script to an empty GameObject. It builds the whole game:
// 5-second loading screen, language choice (Hindi / English / Punjabi), gun shop, big maze maps, guards, coins.
public class Bootstrap : MonoBehaviour
{
    enum St { Intro, Menu, Loading, Play, Dead, Win }
    const string Dev = "Developer: Shiva Kashyap";
    St st = St.Intro; SaveData D; GameObject world; PlayerController pl; TouchJoystick joy; Camera cam;
    int alive; float introT; Texture2D ring, dot, tri; GUIStyle big, mid, small, ctr, btn, btnI, acc; Font indic; Vector2 scroll;

    void Awake()
    {
        Application.targetFrameRate = 60; Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Screen.orientation = ScreenOrientation.AutoRotation;           // phone, tablet, laptop, desktop
        SaveSystem.Load(); D = SaveSystem.Data; Loc.Lang = D.lang;
        cam = Camera.main; if (cam == null) cam = new GameObject("Camera").AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(.03f, .035f, .05f); cam.fieldOfView = 50;
        RenderSettings.ambientLight = new Color(.3f, .33f, .45f);
        joy = gameObject.AddComponent<TouchJoystick>();
        ring = Circle(64, false); dot = Circle(32, true); tri = Triangle(32);
        indic = Font.CreateDynamicFontFromOSFont(new[] { "Noto Sans Devanagari", "Noto Sans Gurmukhi", "Nirmala UI", "Mangal", "Arial Unicode MS", "Arial" }, 24);
    }

    void Update() { if (st == St.Intro) { introT += Time.deltaTime; if (introT >= 5f) st = St.Menu; } }

    void AddCoins(int n) { D.coins += n; SaveSystem.Save(); }

    IEnumerator StartLevel()
    {
        st = St.Loading; joy.Enabled = false;
        if (world) Destroy(world);
        foreach (var b in FindObjectsByType<Bullet>(FindObjectsSortMode.None)) Destroy(b.gameObject);
        yield return null;
        int lv = D.level;
        world = new GameObject("World");
        var map = MapBuilder.Build(world.transform, Mathf.Min(3 + lv, 6), Mathf.Min(4 + lv, 8), Random.Range(0, 99999));

        var pg = new GameObject("Player"); pg.transform.SetParent(world.transform); pg.transform.position = map.roomCenters[0];
        pl = pg.AddComponent<PlayerController>(); pl.Init(Weapons.All[D.gun], joy); Bullet.Player = pl;
        pl.OnDeath = () => { st = St.Dead; joy.Enabled = false; SaveSystem.Save(); };

        int n = Mathf.Min(3 + lv * 2, 14); alive = 0; int tries = 0;
        while (alive < n && tries++ < 800)
        {
            var c = map.roomCenters[Random.Range(1, map.roomCenters.Count)] + new Vector3(Random.Range(-4f, 4f), 0, Random.Range(-4f, 4f)); NavMeshHit h;
            if (Vector3.Distance(c, map.roomCenters[0]) < 20f || !NavMesh.SamplePosition(c, out h, 3f, NavMesh.AllAreas)) continue;
            var gg = new GameObject("Guard"); gg.transform.SetParent(world.transform); gg.transform.position = h.position;
            var gd = gg.AddComponent<Guard>(); gd.Init(pl, map.roomCenters); alive++;
            gd.OnDie = g =>
            {
                AddCoins(10); alive--;                                   // coins only for kills...
                if (alive <= 0 && st == St.Play) { st = St.Win; joy.Enabled = false; AddCoins(100); D.level++; SaveSystem.Save(); }   // ...and level clear
            };
        }
        cam.transform.position = pl.transform.position + new Vector3(0, 17, -10);
        st = St.Play; joy.Enabled = true;
    }

    void LateUpdate()
    {
        if (pl == null) return;
        Vector3 t = pl.transform.position + new Vector3(0, 17, -10);
        cam.transform.position = Vector3.Lerp(cam.transform.position, t, Time.deltaTime * 5f);
        cam.transform.LookAt(pl.transform.position + Vector3.forward * 1.5f);
    }

    void Styles()
    {
        if (big == null)
        {
            big = new GUIStyle(GUI.skin.label) { fontSize = 40, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            mid = new GUIStyle(GUI.skin.label) { fontSize = 20 }; small = new GUIStyle(GUI.skin.label) { fontSize = 16 };
            ctr = new GUIStyle(small) { alignment = TextAnchor.MiddleCenter };
            acc = new GUIStyle(GUI.skin.label) { fontSize = 20, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            btn = new GUIStyle(GUI.skin.button) { fontSize = 20 }; btnI = new GUIStyle(btn) { font = indic };
            big.normal.textColor = mid.normal.textColor = small.normal.textColor = ctr.normal.textColor = Color.white;
            acc.normal.textColor = new Color(.37f, .9f, .77f);
        }
        Font f = Loc.Lang == 1 ? null : indic;
        big.font = mid.font = small.font = ctr.font = btn.font = f;
    }

    void OnGUI()
    {
        joy.Draw(ring, dot);
        float s = Screen.height / 800f; GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1)); float W = Screen.width / s;
        Styles();
        if (st == St.Intro) { Intro(W); return; }
        if (st == St.Loading) return;
        if (st == St.Play) { Hud(W); return; }
        Menu(W);
    }

    void Intro(float W)
    {
        GUI.color = new Color(.03f, .035f, .05f); GUI.DrawTexture(new Rect(0, 0, W, 800), Texture2D.whiteTexture); GUI.color = Color.white;
        GUI.Label(new Rect(0, 290, W, 60), "Elite Umbrix", big); GUI.Label(new Rect(0, 350, W, 30), Dev, acc);
        float p = Mathf.Clamp01(introT / 5f), bw = 280;
        GUI.color = new Color(.1f, .13f, .17f); GUI.DrawTexture(new Rect(W / 2 - bw / 2, 410, bw, 8), Texture2D.whiteTexture);
        GUI.color = new Color(.37f, .9f, .77f); GUI.DrawTexture(new Rect(W / 2 - bw / 2, 410, bw * p, 8), Texture2D.whiteTexture); GUI.color = Color.white;
        GUI.Label(new Rect(0, 425, W, 30), Mathf.FloorToInt(p * 100) + "%", acc);
        GUI.Label(new Rect(20, 470, W - 40, 30), Loc.Get("tip"), ctr);
    }

    void Hud(float W)
    {
        GUI.Label(new Rect(20, 10, W - 40, 34), Loc.Get("lvl") + " " + D.level + "    HP " + pl.hp + "    " + Loc.Get("coins") + " " + D.coins + "    " + Loc.Get("guards") + " " + alive, mid);
        Guard nearest = null; float bd = 1e9f;
        foreach (var g in Guard.All) { if (g == null || g.hp <= 0) continue; float d = (g.transform.position - pl.transform.position).sqrMagnitude; if (d < bd) { bd = d; nearest = g; } }
        if (nearest != null && bd > 64f)       // arrow to the nearest guard
        {
            Vector3 v = nearest.transform.position - pl.transform.position; float a = Mathf.Atan2(v.x, v.z) * Mathf.Rad2Deg; Vector2 c = new Vector2(W / 2, 80);
            var m = GUI.matrix; GUIUtility.RotateAroundPivot(a, c); GUI.DrawTexture(new Rect(c.x - 16, c.y - 16, 32, 32), tri); GUI.matrix = m;
        }
    }

    void Menu(float W)
    {
        float w = Mathf.Min(W - 40, 460), x = (W - w) / 2;
        GUI.Box(new Rect(x - 10, 20, w + 20, 760), "");
        GUI.Label(new Rect(x, 30, w, 56), "Elite Umbrix", big); GUI.Label(new Rect(x, 88, w, 28), Dev, acc);
        string[] ln = { "हिंदी", "English", "ਪੰਜਾਬੀ" }; float bw = (w - 20) / 3;
        for (int i = 0; i < 3; i++)
        {
            GUI.enabled = Loc.Lang != i;
            if (GUI.Button(new Rect(x + i * (bw + 10), 125, bw, 40), ln[i], btnI)) { Loc.Lang = i; D.lang = i; SaveSystem.Save(); }
        }
        GUI.enabled = true;
        string sub = st == St.Dead ? Loc.Get("dead") : st == St.Win ? Loc.Get("win") : Loc.Get("startS");
        GUI.Label(new Rect(x, 172, w, 34), sub, acc);
        GUI.Label(new Rect(x, 208, w, 30), Loc.Get("coins") + ": " + D.coins + "     " + Loc.Get("lvl") + ": " + D.level, ctr);

        float rowH = 92;
        scroll = GUI.BeginScrollView(new Rect(x, 245, w, 420), scroll, new Rect(0, 0, w - 20, rowH * Weapons.All.Length));
        for (int i = 0; i < Weapons.All.Length; i++)
        {
            var g = Weapons.All[i]; float y = i * rowH;
            GUI.Label(new Rect(0, y, w * .56f, 30), g.name, mid);
            GUI.Label(new Rect(0, y + 28, w * .56f, 60), g.note[Loc.Lang] + "\nDMG " + g.damage + (g.pellets > 1 ? "x" + g.pellets : "") + "   " + (1f / g.rate).ToString("0.#") + "/s", small);
            bool own = D.owned[i]; string t = own ? (D.gun == i ? Loc.Get("picked") : Loc.Get("pick")) : Loc.Get("buy") + " " + g.price;
            GUI.enabled = own ? D.gun != i : D.coins >= g.price;
            if (GUI.Button(new Rect(w * .6f, y + 14, w * .36f - 20, 50), t, btn))
            {
                if (own) D.gun = i; else { D.coins -= g.price; D.owned[i] = true; D.gun = i; }
                SaveSystem.Save();
            }
            GUI.enabled = true;
        }
        GUI.EndScrollView();
        string pb = st == St.Win ? Loc.Get("next") : st == St.Dead ? Loc.Get("again") : Loc.Get("play");
        if (GUI.Button(new Rect(x, 672, w, 66), pb, btn)) StartCoroutine(StartLevel());
#if UNITY_STANDALONE
        if (GUI.Button(new Rect(x + w * .3f, 744, w * .4f, 30), Loc.Get("quit"), btn)) Application.Quit();
#endif
    }

    Texture2D Circle(int n, bool fill)
    {
        var t = new Texture2D(n, n, TextureFormat.RGBA32, false); float r = n / 2f - 2;
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
        {
            float d = Vector2.Distance(new Vector2(x, y), new Vector2(n / 2f, n / 2f));
            t.SetPixel(x, y, new Color(1, 1, 1, fill ? (d < r ? .4f : 0) : (Mathf.Abs(d - r) < 2.5f ? .55f : 0)));
        }
        t.Apply(); return t;
    }

    Texture2D Triangle(int n)
    {
        var t = new Texture2D(n, n, TextureFormat.RGBA32, false);
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
        {
            float half = (n - 1 - y) / (float)(n - 1) * (n / 2f);
            t.SetPixel(x, y, Mathf.Abs(x - n / 2f) <= half ? new Color(1f, .35f, .37f, .95f) : new Color(0, 0, 0, 0));
        }
        t.Apply(); return t;
    }
}
