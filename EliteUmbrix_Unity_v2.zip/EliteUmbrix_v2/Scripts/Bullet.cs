using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public static PlayerController Player;
    Vector3 dir; float speed, left; int dmg; bool fromPlayer, pierce; HashSet<Guard> hitSet = new HashSet<Guard>();

    public static void Spawn(Vector3 pos, Vector3 dir, float speed, int dmg, float range, bool fromPlayer, bool pierce, Color col)
    {
        var g = Prim.Cube(null, pos, new Vector3(.07f, .07f, .7f), col, "Bullet");
        g.transform.rotation = Quaternion.LookRotation(dir);
        var mat = g.GetComponent<Renderer>().material; mat.EnableKeyword("_EMISSION"); mat.SetColor("_EmissionColor", col * 3f);
        var tr = g.AddComponent<TrailRenderer>(); tr.time = .12f; tr.startWidth = .1f; tr.endWidth = 0f;
        tr.material = new Material(Shader.Find("Sprites/Default")); tr.startColor = col; tr.endColor = new Color(col.r, col.g, col.b, 0);
        var b = g.AddComponent<Bullet>(); b.dir = dir; b.speed = speed; b.dmg = dmg; b.left = range; b.fromPlayer = fromPlayer; b.pierce = pierce;
    }

    void Update()
    {
        float step = speed * Time.deltaTime; left -= step;
        RaycastHit h;
        if (Physics.Raycast(transform.position, dir, out h, step + .05f, ~0, QueryTriggerInteraction.Ignore))
        {
            var gd = h.collider.GetComponentInParent<Guard>(); var pc = h.collider.GetComponentInParent<PlayerController>();
            if (gd != null) { if (fromPlayer && !hitSet.Contains(gd)) { hitSet.Add(gd); gd.TakeDamage(dmg); if (!pierce) { Destroy(gameObject); return; } } }
            else if (pc != null) { if (!fromPlayer) { pc.Hurt(); Destroy(gameObject); return; } }
            else { Destroy(gameObject); return; }
        }
        transform.position += dir * step;
        if (left <= 0) Destroy(gameObject);
    }
}
