using UnityEngine;

public struct Part
{
    public Vector3 pos, size; public Color col;
    public Part(float x, float y, float z, float sx, float sy, float sz, Color c) { pos = new Vector3(x, y, z); size = new Vector3(sx, sy, sz); col = c; }
}

public class Weapon
{
    public string name; public int damage, price; public int pellets = 1;
    public float rate, speed, range, spread, length; public bool pierce; public Color color;
    public string[] note;   // Hindi, English, Punjabi
    public Part[] parts;
}

public static class Weapons
{
    static Color Metal = new Color(.35f, .37f, .42f), Dark = new Color(.1f, .11f, .13f), Wood = new Color(.5f, .3f, .14f),
                 Olive = new Color(.33f, .4f, .2f), Camo = new Color(.3f, .38f, .16f), Cyan = new Color(.2f, .9f, 1f);
    static Part P(float x, float y, float z, float sx, float sy, float sz, Color c) { return new Part(x, y, z, sx, sy, sz, c); }

    // First 4 are free. The other 10 must be unlocked with coins. Order = order in the save file.
    public static readonly Weapon[] All =
    {
        new Weapon{ name="AK", damage=40, rate=.16f, speed=45, range=16, spread=2, price=0, length=1.25f, color=new Color(1f,.42f,.29f),
            note=new[]{"हर चीज़ में संतुलित","Balanced all-rounder","ਹਰ ਚੀਜ਼ ਵਿੱਚ ਸੰਤੁਲਿਤ"},
            parts=new[]{ P(0,0,.25f,.16f,.2f,.45f,Metal), P(0,-.01f,.68f,.18f,.18f,.4f,Wood), P(0,.03f,1.05f,.06f,.06f,.4f,Metal), P(0,-.28f,.3f,.1f,.3f,.16f,Dark), P(0,-.03f,-.2f,.14f,.22f,.4f,Wood) } },
        new Weapon{ name="MP9", damage=20, rate=.07f, speed=40, range=12, spread=4, price=0, length=.65f, color=new Color(.5f,.83f,1f),
            note=new[]{"सबसे तेज़, कम रेंज","Very fast, short range","ਸਭ ਤੋਂ ਤੇਜ਼, ਘੱਟ ਰੇਂਜ"},
            parts=new[]{ P(0,0,.2f,.16f,.22f,.5f,Dark), P(0,-.28f,.2f,.1f,.3f,.14f,Dark), P(0,.04f,.55f,.06f,.06f,.2f,Metal), P(0,.14f,.1f,.08f,.06f,.12f,Cyan) } },
        new Weapon{ name="M249", damage=25, rate=.09f, speed=42, range=14, spread=5, price=0, length=1.45f, color=new Color(1f,.7f,.28f),
            note=new[]{"तेज़ फायर, ज़्यादा बिखराव","Rapid fire, more spread","ਤੇਜ਼ ਫਾਇਰ, ਵੱਧ ਖਿਲਾਰ"},
            parts=new[]{ P(0,0,.35f,.2f,.24f,.8f,Dark), P(0,.04f,1.15f,.07f,.07f,.7f,Metal), P(0,-.3f,.3f,.3f,.28f,.3f,Olive), P(-.08f,-.2f,1.1f,.04f,.3f,.04f,Metal), P(.08f,-.2f,1.1f,.04f,.3f,.04f,Metal), P(0,-.02f,-.25f,.16f,.2f,.35f,Dark) } },
        new Weapon{ name="AWM", damage=100, rate=1f, speed=80, range=24, spread=0, price=0, length=1.8f, pierce=true, color=new Color(.72f,1f,.42f),
            note=new[]{"एक शॉट एक किल, लंबी रेंज","One shot, one kill, long range","ਇੱਕ ਸ਼ਾਟ ਇੱਕ ਕਿੱਲ, ਲੰਮੀ ਰੇਂਜ"},
            parts=new[]{ P(0,0,.3f,.16f,.2f,.7f,Camo), P(0,.03f,1.25f,.06f,.06f,1.1f,Dark), P(0,.2f,.3f,.1f,.1f,.5f,Dark), P(0,-.05f,-.35f,.16f,.3f,.5f,Camo), P(0,-.16f,.35f,.1f,.14f,.2f,Dark) } },

        new Weapon{ name="Glock 18", damage=22, rate=.08f, speed=38, range=11, spread=4, price=150, length=.45f, color=new Color(.6f,.82f,1f),
            note=new[]{"हल्का ऑटो पिस्टल","Light auto pistol","ਹਲਕਾ ਆਟੋ ਪਿਸਟਲ"},
            parts=new[]{ P(0,0,.03f,.16f,.18f,.52f,Dark), P(0,.03f,.35f,.08f,.08f,.13f,Metal), P(0,-.23f,-.1f,.14f,.33f,.18f,Dark), P(0,-.36f,-.1f,.12f,.2f,.13f,Dark) } },
        new Weapon{ name="Desert Eagle", damage=70, rate=.5f, speed=45, range=13, spread=1.5f, price=250, length=.6f, color=new Color(1f,.82f,.48f),
            note=new[]{"भारी वार, धीमा","Heavy hit, slow","ਭਾਰੀ ਵਾਰ, ਹੌਲੀ"},
            parts=new[]{ P(0,0,.06f,.2f,.23f,.58f,Metal), P(0,.01f,.48f,.13f,.13f,.2f,Metal), P(0,-.26f,-.11f,.17f,.35f,.2f,Wood) } },
        new Weapon{ name="UMP45", damage=28, rate=.1f, speed=40, range=14, spread=3, price=400, length=.7f, color=new Color(.78f,.65f,1f),
            note=new[]{"अच्छा SMG","Solid SMG","ਵਧੀਆ SMG"},
            parts=new[]{ P(0,0,.06f,.2f,.26f,.65f,Dark), P(0,-.33f,.125f,.13f,.39f,.17f,Dark), P(0,.03f,.55f,.09f,.09f,.26f,Metal), P(0,.03f,-.36f,.08f,.1f,.39f,Metal) } },
        new Weapon{ name="Vector", damage=18, rate=.045f, speed=40, range=12, spread=4, price=600, length=.55f, color=new Color(1f,.54f,.85f),
            note=new[]{"बहुत तेज़ फायर","Very high fire rate","ਬਹੁਤ ਤੇਜ਼ ਫਾਇਰ"},
            parts=new[]{ P(0,0,.03f,.2f,.29f,.58f,Dark), P(0,-.36f,.16f,.13f,.46f,.2f,Dark), P(0,.05f,.42f,.1f,.1f,.2f,Metal), P(0,.03f,-.27f,.07f,.2f,.1f,Metal) } },
        new Weapon{ name="M4A1", damage=34, rate=.11f, speed=48, range=17, spread=2, price=800, length=1.1f, color=new Color(.42f,1f,.62f),
            note=new[]{"सटीक राइफल","Accurate rifle","ਸਟੀਕ ਰਾਈਫਲ"},
            parts=new[]{ P(0,0,.03f,.17f,.23f,.52f,Dark), P(0,0,.52f,.2f,.2f,.52f,Metal), P(0,.03f,.9f,.07f,.07f,.33f,Metal), P(0,-.29f,.125f,.13f,.36f,.17f,Dark), P(0,-.04f,-.4f,.14f,.23f,.39f,Dark), P(0,.17f,.06f,.07f,.1f,.39f,Metal) } },
        new Weapon{ name="SCAR-H", damage=55, rate=.15f, speed=50, range=18, spread=1.5f, price=1100, length=1.2f, color=new Color(1f,.88f,.4f),
            note=new[]{"दमदार राइफल","Powerful rifle","ਦਮਦਾਰ ਰਾਈਫਲ"},
            parts=new[]{ P(0,0,.06f,.2f,.26f,.65f,Wood), P(0,0,.58f,.21f,.21f,.46f,Wood), P(0,.03f,.97f,.08f,.08f,.39f,Dark), P(0,-.33f,.16f,.14f,.39f,.2f,Dark), P(0,-.05f,-.43f,.17f,.26f,.46f,Wood), P(0,.22f,.125f,.1f,.1f,.33f,Dark) } },
        new Weapon{ name="M1014", damage=30, rate=.7f, speed=38, range=10, spread=8, pellets=6, price=1400, length=1.15f, color=new Color(1f,.48f,.27f),
            note=new[]{"शॉटगन, 6 छर्रे","Shotgun, 6 pellets","ਸ਼ਾਟਗਨ, 6 ਛਰ੍ਹੇ"},
            parts=new[]{ P(0,0,0,.2f,.23f,.58f,Dark), P(0,.04f,.71f,.1f,.1f,.91f,Metal), P(0,-.1f,.52f,.18f,.16f,.33f,Wood), P(0,-.08f,.65f,.09f,.09f,.78f,Metal), P(0,-.04f,-.4f,.16f,.26f,.39f,Wood) } },
        new Weapon{ name="Dragunov", damage=85, rate=.65f, speed=65, range=22, spread=.3f, price=1800, length=1.4f, color=new Color(.6f,.89f,.48f),
            note=new[]{"स्नाइपर, लंबी रेंज","Sniper, long range","ਸਨਾਈਪਰ, ਲੰਮੀ ਰੇਂਜ"},
            parts=new[]{ P(0,0,.03f,.17f,.21f,.65f,Wood), P(0,.03f,.84f,.07f,.07f,1.04f,Dark), P(0,.21f,.06f,.09f,.09f,.33f,Dark), P(0,-.03f,-.4f,.13f,.26f,.39f,Wood), P(0,-.23f,.06f,.12f,.26f,.16f,Dark) } },
        new Weapon{ name="M82 Barrett", damage=150, rate=1.3f, speed=85, range=26, spread=0, pierce=true, price=2500, length=1.95f, color=new Color(1f,.3f,.43f),
            note=new[]{"भेदने वाली गोली","Piercing round","ਆਰ-ਪਾਰ ਜਾਣ ਵਾਲੀ ਗੋਲੀ"},
            parts=new[]{ P(0,0,.06f,.22f,.26f,.78f,Dark), P(0,.05f,1.1f,.1f,.1f,1.3f,Metal), P(0,.05f,1.82f,.17f,.17f,.2f,Metal), P(0,.25f,.125f,.13f,.13f,.52f,Dark), P(-.1f,-.23f,1.23f,.04f,.33f,.04f,Metal), P(.1f,-.23f,1.23f,.04f,.33f,.04f,Metal), P(0,-.04f,-.53f,.2f,.29f,.46f,Dark), P(0,-.21f,.125f,.16f,.2f,.33f,Olive) } },
        new Weapon{ name="M134 Minigun", damage=14, rate=.03f, speed=42, range=15, spread=7, price=3500, length=1.05f, color=Color.white,
            note=new[]{"गोलियों की बौछार","Bullet storm","ਗੋਲੀਆਂ ਦੀ ਵਾਛੜ"},
            parts=new[]{ P(0,0,.45f,.23f,.23f,.91f,Metal), P(-.09f,.09f,.5f,.07f,.07f,1.04f,Dark), P(.09f,.09f,.5f,.07f,.07f,1.04f,Dark), P(-.09f,-.09f,.5f,.07f,.07f,1.04f,Dark), P(.09f,-.09f,.5f,.07f,.07f,1.04f,Dark), P(0,0,-.07f,.29f,.33f,.39f,Dark), P(0,-.33f,0,.33f,.33f,.26f,Olive), P(0,.22f,-.07f,.07f,.2f,.07f,Metal) } },
    };

    public static Transform Build(Weapon w, Transform mount)
    {
        var g = new GameObject("Gun").transform; g.SetParent(mount, false);
        foreach (var p in w.parts) Prim.Cube(g, p.pos, p.size, p.col);
        var mz = new GameObject("Muzzle").transform; mz.SetParent(g, false); mz.localPosition = new Vector3(0, .03f, w.length);
        return g;
    }
}
