using System.IO;
using UnityEngine;

// Everything is saved on the device (works fully offline).
[System.Serializable]
public class SaveData { public int coins; public int level = 1; public int gun = 0; public int lang = 1; public bool[] owned; }

public static class SaveSystem
{
    public static SaveData Data;
    static string PathFile { get { return Path.Combine(Application.persistentDataPath, "umbrix_save.json"); } }
    public static void Load()
    {
        try { if (File.Exists(PathFile)) Data = JsonUtility.FromJson<SaveData>(File.ReadAllText(PathFile)); } catch { }
        if (Data == null) Data = new SaveData();
        var o = new bool[Weapons.All.Length];
        if (Data.owned != null) for (int i = 0; i < Mathf.Min(o.Length, Data.owned.Length); i++) o[i] = Data.owned[i];
        for (int i = 0; i < 4; i++) o[i] = true;                 // AK, MP9, M249, AWM are free
        Data.owned = o;
        if (Data.gun < 0 || Data.gun >= o.Length || !o[Data.gun]) Data.gun = 0;
        if (Data.lang < 0 || Data.lang > 2) Data.lang = 1;
        if (Data.level < 1) Data.level = 1;
    }
    public static void Save() { try { File.WriteAllText(PathFile, JsonUtility.ToJson(Data)); } catch { } }
}
