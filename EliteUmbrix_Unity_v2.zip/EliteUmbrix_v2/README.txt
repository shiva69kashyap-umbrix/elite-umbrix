ELITE UMBRIX (Unity) - v2
Developer: Shiva Kashyap
=========================
Everything from the browser version is in this package:
- Big random maze maps (grow every level), crates for cover, guards that patrol on a NavMesh
- 14 guns: AK, MP9, M249, AWM are free; Glock 18, Desert Eagle, UMP45, Vector, M4A1, SCAR-H,
  M1014 (shotgun), Dragunov, M82 Barrett, M134 Minigun are unlocked with coins
- Coins only from kills (+10) and level clear (+100)
- Auto-fire, red arrow to nearest guard, 3 lives
- 5-second loading screen with game name + developer name
- Languages: Hindi / English / Punjabi (buttons on the menu)
- 100% offline. Progress is saved locally (persistentDataPath/umbrix_save.json)

SETUP
1. Install Unity Hub + the newest Unity 6 LTS. Add modules: Android Build Support (OpenJDK, SDK & NDK),
   and Windows / Mac / Linux Build Support if you want PC builds.
2. New project -> "3D (Built-in Render Pipeline)".
3. Window > Package Manager > Unity Registry > install "AI Navigation".
4. Project Settings > Player > Other Settings > Active Input Handling = "Both" (restart editor if asked).
5. Create Assets/Scripts and copy ALL .cs files from the Scripts folder into it.
   (If you used the first package, delete its old Coin.cs - coins on the ground were removed.)
6. In the scene: GameObject > Create Empty > add the "Bootstrap" component. Press Play.
   Controls: touch/mouse drag = floating joystick, or WASD / arrow keys. Fire is automatic.

BUILD FOR EVERY DEVICE (one project, same scripts)
- Android phone + tablet: File > Build Settings > Android > Switch Platform.
  Player Settings: Product Name "Elite Umbrix", Package Name com.shivakashyap.eliteumbrix,
  Default Orientation = Auto Rotation, Scripting Backend = IL2CPP, ARM64 ON,
  Target API Level = Android 16 (API 36) (needed for new Play Store apps from 31 Aug 2026),
  Minimum API 24. Tick "Build App Bundle (Google Play)" for the Play Store (.aab), or untick for a test .apk.
- Windows PC / laptop: Build Settings > Windows, Mac, Linux > Windows > Build.
- Mac / Linux: same, choose the target platform.
- Optional: WebGL build to run inside a browser.

KNOWN LIMITATION - HINDI / PUNJABI TEXT
Unity's built-in text does not join Indic letters correctly (some matras / conjuncts show wrongly).
English always looks right. For perfect Hindi/Punjabi in the Unity build you need a text-shaping
solution (an Asset Store Indic-text plugin for TextMeshPro) or pre-rendered images for those strings.
The browser version already shows Hindi and Punjabi correctly.

NOT TESTED INSIDE UNITY: I cannot open Unity myself, so expect small fixes on first run.
Send me any red error text from the Console and I will fix it.
